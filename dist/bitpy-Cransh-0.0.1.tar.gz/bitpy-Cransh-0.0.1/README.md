# bitpy
Better Bool Type for Python

add Falling edge and Rising edge Detection function for Bool-like Type.

You can check test.py module to see how to use 